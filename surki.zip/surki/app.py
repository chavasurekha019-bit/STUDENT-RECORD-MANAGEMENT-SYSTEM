from flask import Flask, render_template, request, redirect
import json, os

app = Flask(__name__)
DATA_FILE = "students.json"

# ---------------- Linked List Implementation ----------------
class Node:
    def __init__(self, roll_no, name, age, department, email, grade):
        self.roll_no = roll_no
        self.name = name
        self.age = age
        self.department = department
        self.email = email
        self.grade = grade
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def insert(self, roll_no, name, age, department, email, grade):
        new_node = Node(roll_no, name, age, department, email, grade)
        if not self.head:
            self.head = new_node
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = new_node
        self.save_to_file()

    def delete(self, roll_no):
        current = self.head
        prev = None
        while current:
            if current.roll_no == roll_no:
                if prev:
                    prev.next = current.next
                else:
                    self.head = current.next
                self.save_to_file()
                return True
            prev = current
            current = current.next
        return False

    def update(self, roll_no, name, age, department, email, grade):
        current = self.head
        while current:
            if current.roll_no == roll_no:
                current.name = name
                current.age = age
                current.department = department
                current.email = email
                current.grade = grade
                self.save_to_file()
                return True
            current = current.next
        return False

    def get(self, roll_no):
        current = self.head
        while current:
            if current.roll_no == roll_no:
                return current
            current = current.next
        return None

    def display(self):
        students = []
        current = self.head
        while current:
            students.append({
                "roll_no": current.roll_no,
                "name": current.name,
                "age": current.age,
                "department": current.department,
                "email": current.email,
                "grade": current.grade
            })
            current = current.next
        return students

    # ---------------- Persistence Methods ----------------
    def save_to_file(self):
        data = self.display()
        with open(DATA_FILE, "w") as f:
            json.dump(data, f, indent=4)

    def load_from_file(self):
        if not os.path.exists(DATA_FILE):
            return
        with open(DATA_FILE, "r") as f:
            try:
                data = json.load(f)
                for student in data:
                    self.insert(
                        student["roll_no"],
                        student["name"],
                        student["age"],
                        student["department"],
                        student["email"],
                        student["grade"]
                    )
            except json.JSONDecodeError:
                pass


# ---------------- App Logic ----------------
student_list = LinkedList()
student_list.load_from_file()  # load existing data on startup

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        roll_no = request.form.get("roll_no")
        name = request.form.get("name")
        age = request.form.get("age")
        department = request.form.get("department")
        email = request.form.get("email")
        grade = request.form.get("grade")
        mode = request.form.get("mode")

        if mode == "add":
            print(f"[DEBUG] Adding: roll_no={roll_no}, name={name}, age={age}, department={department}, email={email}, grade={grade}")
            student_list.insert(roll_no, name, age, department, email, grade)
        elif mode == "edit":
            print(f"[DEBUG] Editing: roll_no={roll_no}, name={name}, age={age}, department={department}, email={email}, grade={grade}")
            updated = student_list.update(roll_no, name, age, department, email, grade)
            print(f"[DEBUG] Update result: {updated}")

        return redirect("/")

    students = student_list.display()
    return render_template("index.html", students=students, edit_student=None)

@app.route("/delete/<roll_no>")
def delete(roll_no):
    student_list.delete(roll_no)
    return redirect("/")

@app.route("/edit/<roll_no>")
def edit(roll_no):
    students = student_list.display()
    student = student_list.get(roll_no)
    return render_template("index.html", students=students, edit_student=student)


if __name__ == "__main__":
    app.run(debug=True)
